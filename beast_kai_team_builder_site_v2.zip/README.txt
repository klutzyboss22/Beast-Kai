Beast Kai Team Builder v2

Static browser-based team builder, focused on the team-building side first.

Added:
- more Showdown-like layout
- beast inspector panel
- move detail popup modals
- role and ability filters
- sample team shells
- improved sorting and browsing

Open index.html in a browser.
